from types import SimpleNamespace as N
from app.signal_engine import score_trade

def t(risk=25000,side='yes',yes=.55,no=.45,count=45454,ts=1000,block=False): return N(risk_dollars=risk,side=side,yes_price=yes,no_price=no,count=count,ts=ts,is_block_trade=block)
def test_big_cluster_scores_higher():
    market=N(volume_24h=500000,close_ts=2000)
    base=t(risk=1000,count=1800)
    big=t(risk=100000,count=180000,block=True)
    r1=score_trade(trade=base,market=market,nearby=[base],prior=None)
    r2=score_trade(trade=big,market=market,nearby=[big,t(50000,ts=990),t(40000,ts=995)],prior=t(10000,yes=.50,no=.50,ts=990))
    assert r2.score>r1.score
    assert r2.label in {'STRONG','EXTREME'}
