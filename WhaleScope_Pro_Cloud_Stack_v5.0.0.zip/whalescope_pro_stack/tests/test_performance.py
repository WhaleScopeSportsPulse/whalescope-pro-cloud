from app.evaluator import directional

def test_directional_yes_no():
    assert round(directional(.50,.55,'yes'),3)==5
    assert round(directional(.50,.45,'no'),3)==5
