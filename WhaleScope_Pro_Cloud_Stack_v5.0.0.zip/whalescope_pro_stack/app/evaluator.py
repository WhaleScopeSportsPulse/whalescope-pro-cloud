from __future__ import annotations
import time
from sqlalchemy import select
from .db import SessionLocal
from .models import SignalFollowup, Signal, Trade

def directional(entry_yes:float, observed_yes:float, side:str)->float:
    return (observed_yes-entry_yes)*100*(1 if side=="yes" else -1)

def evaluate_due(limit:int=1000)->int:
    now=int(time.time()); n=0
    with SessionLocal() as s:
        rows=s.execute(select(SignalFollowup).where(SignalFollowup.resolved==False,SignalFollowup.target_ts<=now).order_by(SignalFollowup.target_ts).limit(limit)).scalars().all()
        for fu in rows:
            sig=s.get(Signal,fu.signal_id)
            if not sig: fu.resolved=True; continue
            obs=s.execute(select(Trade).where(Trade.ticker==sig.ticker,Trade.ts>=fu.target_ts).order_by(Trade.ts.asc()).limit(1)).scalar_one_or_none()
            if not obs: continue
            horizon_rows=s.execute(select(Trade).where(Trade.ticker==sig.ticker,Trade.ts>=sig.ts,Trade.ts<=obs.ts).order_by(Trade.ts)).scalars().all()
            moves=[directional(sig.entry_price if sig.side=="yes" else 1-sig.entry_price, t.yes_price, sig.side) for t in horizon_rows]
            fu.observed_ts=obs.ts; fu.observed_yes_price=obs.yes_price
            entry_yes=s.get(Trade,sig.trade_id).yes_price if s.get(Trade,sig.trade_id) else (sig.entry_price if sig.side=="yes" else 1-sig.entry_price)
            fu.directional_move_cents=directional(entry_yes,obs.yes_price,sig.side)
            fu.max_favorable_cents=max(moves) if moves else fu.directional_move_cents
            fu.max_adverse_cents=min(moves) if moves else fu.directional_move_cents
            outcome=""
            for mv in moves:
                if mv>=5: outcome="favorable"; break
                if mv<=-5: outcome="adverse"; break
            fu.first_5c_outcome=outcome
            fu.resolved=True; n+=1
        s.commit()
    return n
