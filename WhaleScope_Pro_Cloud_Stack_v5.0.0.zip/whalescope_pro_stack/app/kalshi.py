from __future__ import annotations
import httpx
from .config import settings

class KalshiClient:
    def __init__(self):
        self.base=settings.kalshi_api_base.rstrip("/")
        self.client=httpx.AsyncClient(timeout=httpx.Timeout(15.0,connect=8.0),headers={"Accept":"application/json","User-Agent":"WhaleScope/5.0"})
    async def close(self): await self.client.aclose()
    async def get(self,path:str,params:dict|None=None):
        r=await self.client.get(self.base+path,params=params or {})
        r.raise_for_status(); return r.json()
    async def trades(self, min_ts:int, cursor:str="", limit:int=1000):
        p={"limit":limit,"min_ts":min_ts}
        if cursor: p["cursor"]=cursor
        return await self.get("/markets/trades",p)
    async def market(self,ticker:str): return await self.get(f"/markets/{ticker}")
    async def event(self,ticker:str): return await self.get(f"/events/{ticker}")
    async def series(self,ticker:str): return await self.get(f"/series/{ticker}")
    async def orderbook(self,ticker:str,depth:int=100): return await self.get(f"/markets/{ticker}/orderbook",{"depth":depth})
