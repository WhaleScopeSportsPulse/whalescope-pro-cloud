from __future__ import annotations
from datetime import datetime
import json, math

SPORT_WORDS = {
    "football": ["NFL","CFB","NCAAF","NCAA FOOTBALL","FOOTBALL","SUPER BOWL"],
    "basketball": ["NBA","WNBA","NCAAB","COLLEGE BASKETBALL","BASKETBALL"],
    "baseball": ["MLB","BASEBALL","WORLD SERIES"],
    "hockey": ["NHL","HOCKEY"],
    "soccer": ["SOCCER","EPL","PREMIER LEAGUE","MLS","CHAMPIONS LEAGUE","UCL","LALIGA","BUNDESLIGA","SERIE A","LIGUE 1"],
    "tennis": ["TENNIS","ATP","WTA","WIMBLEDON","US OPEN","ROLAND GARROS","AUSTRALIAN OPEN"],
    "golf": ["GOLF","PGA","MASTERS"],
    "combat": ["UFC","MMA","BOXING"],
    "motorsport": ["NASCAR","FORMULA 1","F1","INDYCAR"],
}

def f(v, d=0.0):
    try:
        x=float(v)
        return x if math.isfinite(x) else d
    except (TypeError, ValueError): return d

def parse_ts(v) -> int:
    if not v: return 0
    if isinstance(v,(int,float)): return int(v)
    try: return int(datetime.fromisoformat(str(v).replace("Z","+00:00")).timestamp())
    except Exception: return 0

def detect_sport(*texts: str) -> str:
    hay=" ".join(str(x or "") for x in texts).upper()
    for sport, words in SPORT_WORDS.items():
        if any(w in hay for w in words): return sport
    return ""

def label(score:int) -> str:
    if score>=82: return "EXTREME"
    if score>=68: return "STRONG"
    if score>=52: return "ELEVATED"
    if score>=36: return "WATCH"
    return "LOW"

def jdumps(v) -> str:
    return json.dumps(v,separators=(",",":"),ensure_ascii=False)
