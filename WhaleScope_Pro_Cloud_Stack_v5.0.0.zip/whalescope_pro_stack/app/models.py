from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import String, Float, Integer, Boolean, DateTime, Text, ForeignKey, UniqueConstraint, Index
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

def utcnow(): return datetime.now(timezone.utc)

class Market(Base):
    __tablename__ = "markets"
    ticker: Mapped[str] = mapped_column(String(160), primary_key=True)
    event_ticker: Mapped[str] = mapped_column(String(160), default="", index=True)
    series_ticker: Mapped[str] = mapped_column(String(160), default="", index=True)
    title: Mapped[str] = mapped_column(Text, default="")
    event_title: Mapped[str] = mapped_column(Text, default="")
    series_title: Mapped[str] = mapped_column(Text, default="")
    category: Mapped[str] = mapped_column(String(120), default="", index=True)
    sport: Mapped[str] = mapped_column(String(80), default="", index=True)
    status: Mapped[str] = mapped_column(String(40), default="")
    close_ts: Mapped[int] = mapped_column(Integer, default=0, index=True)
    volume_24h: Mapped[float] = mapped_column(Float, default=0)
    open_interest: Mapped[float] = mapped_column(Float, default=0)
    yes_bid: Mapped[float] = mapped_column(Float, default=0)
    yes_ask: Mapped[float] = mapped_column(Float, default=0)
    liquidity_dollars: Mapped[float] = mapped_column(Float, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)

class Trade(Base):
    __tablename__ = "trades"
    trade_id: Mapped[str] = mapped_column(String(160), primary_key=True)
    ticker: Mapped[str] = mapped_column(ForeignKey("markets.ticker", ondelete="CASCADE"), index=True)
    ts: Mapped[int] = mapped_column(Integer, index=True)
    side: Mapped[str] = mapped_column(String(8), index=True)
    yes_price: Mapped[float] = mapped_column(Float)
    no_price: Mapped[float] = mapped_column(Float)
    count: Mapped[float] = mapped_column(Float)
    risk_dollars: Mapped[float] = mapped_column(Float, index=True)
    is_block_trade: Mapped[bool] = mapped_column(Boolean, default=False)
    raw_json: Mapped[str] = mapped_column(Text, default="")
    market: Mapped[Market] = relationship()
    __table_args__ = (Index("ix_trades_ticker_ts", "ticker", "ts"),)

class Signal(Base):
    __tablename__ = "signals"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    trade_id: Mapped[str] = mapped_column(ForeignKey("trades.trade_id", ondelete="CASCADE"), unique=True, index=True)
    ticker: Mapped[str] = mapped_column(String(160), index=True)
    ts: Mapped[int] = mapped_column(Integer, index=True)
    side: Mapped[str] = mapped_column(String(8), index=True)
    entry_price: Mapped[float] = mapped_column(Float)
    risk_dollars: Mapped[float] = mapped_column(Float, index=True)
    score: Mapped[int] = mapped_column(Integer, index=True)
    label: Mapped[str] = mapped_column(String(20), index=True)
    model_version: Mapped[str] = mapped_column(String(40), index=True)
    size_score: Mapped[int] = mapped_column(Integer)
    timing_score: Mapped[int] = mapped_column(Integer)
    cluster_score: Mapped[int] = mapped_column(Integer)
    momentum_score: Mapped[int] = mapped_column(Integer)
    share_score: Mapped[int] = mapped_column(Integer)
    nearby_same_side: Mapped[int] = mapped_column(Integer, default=0)
    burst_risk_dollars: Mapped[float] = mapped_column(Float, default=0)
    directional_move_cents: Mapped[float] = mapped_column(Float, default=0)
    share_of_24h_volume_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    seconds_to_close: Mapped[int | None] = mapped_column(Integer, nullable=True)
    reasons_json: Mapped[str] = mapped_column(Text, default="[]")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    followups: Mapped[list["SignalFollowup"]] = relationship(back_populates="signal", cascade="all,delete-orphan")

class SignalFollowup(Base):
    __tablename__ = "signal_followups"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    signal_id: Mapped[int] = mapped_column(ForeignKey("signals.id", ondelete="CASCADE"), index=True)
    horizon_seconds: Mapped[int] = mapped_column(Integer, index=True)
    target_ts: Mapped[int] = mapped_column(Integer, index=True)
    observed_ts: Mapped[int | None] = mapped_column(Integer, nullable=True)
    observed_yes_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    directional_move_cents: Mapped[float | None] = mapped_column(Float, nullable=True)
    max_favorable_cents: Mapped[float | None] = mapped_column(Float, nullable=True)
    max_adverse_cents: Mapped[float | None] = mapped_column(Float, nullable=True)
    first_5c_outcome: Mapped[str] = mapped_column(String(16), default="")
    resolved: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    signal: Mapped[Signal] = relationship(back_populates="followups")
    __table_args__ = (UniqueConstraint("signal_id","horizon_seconds", name="uq_signal_horizon"),)

class CollectorState(Base):
    __tablename__ = "collector_state"
    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    access_token: Mapped[str] = mapped_column(String(160), unique=True, index=True)
    stripe_customer_id: Mapped[str] = mapped_column(String(160), default="", index=True)
    subscription_status: Mapped[str] = mapped_column(String(40), default="trial", index=True)
    subscription_expires_ts: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

class AlertRule(Base):
    __tablename__ = "alert_rules"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    min_score: Mapped[int] = mapped_column(Integer, default=68)
    min_risk: Mapped[float] = mapped_column(Float, default=10000)
    sport: Mapped[str] = mapped_column(String(80), default="")
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)

class Device(Base):
    __tablename__ = "devices"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    provider: Mapped[str] = mapped_column(String(40), default="onesignal")
    push_token: Mapped[str] = mapped_column(String(512), unique=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
