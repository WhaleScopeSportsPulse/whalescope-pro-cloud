from __future__ import annotations
import os
from dataclasses import dataclass


def _i(name: str, default: int) -> int:
    try: return int(os.getenv(name, str(default)))
    except ValueError: return default

def _f(name: str, default: float) -> float:
    try: return float(os.getenv(name, str(default)))
    except ValueError: return default

@dataclass(frozen=True)
class Settings:
    app_env: str = os.getenv("APP_ENV", "development")
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./whalescope.db")
    kalshi_api_base: str = os.getenv("KALSHI_API_BASE", "https://external-api.kalshi.com/trade-api/v2")
    model_version: str = os.getenv("MODEL_VERSION", "5.0.0")
    collector_poll_seconds: int = _i("COLLECTOR_POLL_SECONDS", 5)
    backfill_hours: int = _i("BACKFILL_HOURS", 72)
    signal_min_risk: float = _f("SIGNAL_MIN_RISK", 500)
    signal_store_min_score: int = _i("SIGNAL_STORE_MIN_SCORE", 30)
    api_public_base: str = os.getenv("API_PUBLIC_BASE", "http://localhost:8080")
    master_api_key: str = os.getenv("MASTER_API_KEY", "")
    stripe_secret_key: str = os.getenv("STRIPE_SECRET_KEY", "")
    stripe_webhook_secret: str = os.getenv("STRIPE_WEBHOOK_SECRET", "")
    stripe_price_id: str = os.getenv("STRIPE_PRICE_ID", "")
    stripe_success_url: str = os.getenv("STRIPE_SUCCESS_URL", "")
    stripe_cancel_url: str = os.getenv("STRIPE_CANCEL_URL", "")
    onesignal_app_id: str = os.getenv("ONESIGNAL_APP_ID", "")
    onesignal_rest_api_key: str = os.getenv("ONESIGNAL_REST_API_KEY", "")

settings = Settings()
