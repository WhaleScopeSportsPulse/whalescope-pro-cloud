from __future__ import annotations
from dataclasses import dataclass
from .util import f,label

@dataclass
class SignalResult:
    score:int; label:str; size_score:int; timing_score:int; cluster_score:int; momentum_score:int; share_score:int
    nearby_same_side:int; burst_risk_dollars:float; directional_move_cents:float; share_of_24h_volume_pct:float|None; seconds_to_close:int|None; reasons:list[str]

def score_trade(*, trade, market, nearby, prior):
    risk=f(trade.risk_dollars); side=trade.side; entry=trade.no_price if side=="no" else trade.yes_price
    same=[x for x in nearby if x.side==side]
    burst=sum(f(x.risk_dollars) for x in same)
    move=0.0
    if prior:
        move=(f(trade.yes_price)-f(prior.yes_price))*100*(1 if side=="yes" else -1)
    vol=f(getattr(market,"volume_24h",0)); share=(f(trade.count)/vol*100) if vol>0 else None
    close_ts=int(getattr(market,"close_ts",0) or 0)
    secs=(close_ts-int(trade.ts)) if close_ts else None
    size_score=round(max(8,min(100,20+(__import__('math').log10(max(1,risk/1000)))*36)))
    timing_score=20 if secs is None else (5 if secs<=0 else 100 if secs<=900 else 90 if secs<=3600 else 78 if secs<=7200 else 60 if secs<=21600 else 38 if secs<=86400 else 20)
    cluster_score=round(min(100,18+max(0,len(same)-1)*15+max(0,min(25,(burst/max(risk,1)-1)*14))))
    momentum_score=round(max(8,min(100,20+max(0,move)*28)))
    share_score=15 if share is None else round(min(100,15+share*10))
    block_boost=7 if trade.is_block_trade else 0
    late_penalty=12 if entry>=.97 and secs is not None and secs<3600 else 0
    score=round(max(1,min(100,size_score*.42+timing_score*.20+cluster_score*.18+momentum_score*.15+share_score*.05+block_boost-late_penalty)))
    reasons=[]
    if risk>=1_000_000: reasons.append(f"${risk:,.0f} was one seven-figure public execution")
    elif risk>=100_000: reasons.append(f"${risk:,.0f} was one six-figure public execution")
    else: reasons.append(f"${risk:,.0f} was one qualifying public execution")
    if len(same)>=2: reasons.append(f"{len(same)} same-side executions appeared within ±2 minutes")
    if secs is not None and 0<secs<=7200: reasons.append(f"execution landed {max(1,round(secs/60))} minutes before market close")
    elif secs is not None and 0<secs<=21600: reasons.append("execution landed within 6 hours of market close")
    if move>=.5: reasons.append(f"price had already moved {move:.1f}¢ toward the observed side")
    if trade.is_block_trade: reasons.append("Kalshi marks this execution as a block trade")
    if share is not None and share>=.5: reasons.append(f"this execution was {share:.2f}% of displayed 24h contract volume")
    if late_penalty: reasons.append("score reduced because entry was already near 100¢ close to settlement")
    return SignalResult(score,label(score),size_score,timing_score,cluster_score,momentum_score,share_score,len(same),burst,move,share,secs,reasons)
