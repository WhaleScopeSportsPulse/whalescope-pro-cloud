from __future__ import annotations
import secrets, time
from sqlalchemy import select
from .config import settings
from .db import SessionLocal
from .models import User

def ensure_user(email:str)->User:
    email=email.strip().lower()
    with SessionLocal() as s:
        u=s.execute(select(User).where(User.email==email)).scalar_one_or_none()
        if not u:
            u=User(email=email,access_token=secrets.token_urlsafe(32),subscription_status="trial",subscription_expires_ts=int(time.time())+7*86400);s.add(u);s.commit();s.refresh(u)
        s.expunge(u);return u

def create_checkout(email:str):
    if not settings.stripe_secret_key or not settings.stripe_price_id: return {"configured":False}
    import stripe
    stripe.api_key=settings.stripe_secret_key
    u=ensure_user(email)
    session=stripe.checkout.Session.create(mode="subscription",customer_email=email,line_items=[{"price":settings.stripe_price_id,"quantity":1}],success_url=settings.stripe_success_url+"?session_id={CHECKOUT_SESSION_ID}",cancel_url=settings.stripe_cancel_url,metadata={"user_id":str(u.id)})
    return {"configured":True,"checkout_url":session.url}

def activate_from_stripe_customer(customer_id:str,status:str="active"):
    with SessionLocal() as s:
        u=s.execute(select(User).where(User.stripe_customer_id==customer_id)).scalar_one_or_none()
        if u:
            u.subscription_status=status;s.commit();return True
    return False
