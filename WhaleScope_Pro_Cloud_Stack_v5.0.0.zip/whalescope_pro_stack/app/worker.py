from __future__ import annotations
import asyncio, time
from .db import init_db
from .collector import Collector
from .evaluator import evaluate_due
from .notifications import dispatch_new_signals

async def main():
    init_db(); c=Collector(); initial=True; last_eval=0
    try:
        while True:
            await c.scan_once(initial=initial); initial=False
            await dispatch_new_signals()
            now=time.time()
            if now-last_eval>=10:
                evaluate_due();last_eval=now
            await asyncio.sleep(5)
    finally: await c.close()

if __name__=="__main__": asyncio.run(main())
