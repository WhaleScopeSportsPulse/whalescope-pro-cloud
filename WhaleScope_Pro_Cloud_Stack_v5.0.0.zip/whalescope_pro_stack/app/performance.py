from __future__ import annotations
from sqlalchemy import select
from .db import SessionLocal
from .models import Signal, SignalFollowup

def _median(a):
    b=sorted(a);m=len(b)//2
    return b[m] if len(b)%2 else (b[m-1]+b[m])/2

def stats(min_score:int=68, horizon:int=1800, model_version:str|None=None, max_score:int|None=None):
    with SessionLocal() as s:
        q=select(SignalFollowup,Signal).join(Signal,Signal.id==SignalFollowup.signal_id).where(SignalFollowup.horizon_seconds==horizon,SignalFollowup.resolved==True,Signal.score>=min_score)
        if max_score is not None:q=q.where(Signal.score<=max_score)
        if model_version:q=q.where(Signal.model_version==model_version)
        rows=s.execute(q).all()
    vals=[float(fu.directional_move_cents or 0) for fu,_ in rows]
    fav=[float(fu.max_favorable_cents or 0) for fu,_ in rows]
    adv=[float(fu.max_adverse_cents or 0) for fu,_ in rows]
    n=len(vals)
    if not n:return {"sample":0,"hit_positive_pct":None,"hit_5c_pct":None,"first_5c_favorable_pct":None,"median_move_cents":None,"median_max_favorable_cents":None,"median_max_adverse_cents":None}
    crossed=[fu.first_5c_outcome for fu,_ in rows if fu.first_5c_outcome in {"favorable","adverse"}]
    first=(sum(x=="favorable" for x in crossed)/len(crossed)*100) if crossed else None
    return {"sample":n,"hit_positive_pct":round(sum(v>0 for v in vals)/n*100,1),"hit_5c_pct":round(sum(v>=5 for v in vals)/n*100,1),"first_5c_favorable_pct":round(first,1) if first is not None else None,"threshold_cross_sample":len(crossed),"median_move_cents":round(_median(vals),2),"median_max_favorable_cents":round(_median(fav),2),"median_max_adverse_cents":round(_median(adv),2)}
