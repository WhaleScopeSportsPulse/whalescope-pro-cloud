from __future__ import annotations
import httpx
from sqlalchemy import select
from .config import settings
from .db import SessionLocal
from .models import Signal, Market, AlertRule, Device, CollectorState

async def send_onesignal(player_ids:list[str],title:str,body:str,data:dict|None=None):
    if not settings.onesignal_app_id or not settings.onesignal_rest_api_key or not player_ids: return {"sent":False,"reason":"provider_not_configured"}
    payload={"app_id":settings.onesignal_app_id,"include_player_ids":player_ids,"headings":{"en":title},"contents":{"en":body},"data":data or {}}
    headers={"Authorization":f"Basic {settings.onesignal_rest_api_key}","Content-Type":"application/json"}
    async with httpx.AsyncClient(timeout=15) as c:
        r=await c.post("https://api.onesignal.com/notifications",json=payload,headers=headers);r.raise_for_status();return {"sent":True,"response":r.json()}

async def dispatch_new_signals():
    with SessionLocal() as s:
        st=s.get(CollectorState,"last_notified_signal_id")
        last=int(st.value) if st and st.value.isdigit() else 0
        signals=s.execute(select(Signal).where(Signal.id>last).order_by(Signal.id).limit(500)).scalars().all()
        if not signals:return 0
        sent=0
        for sig in signals:
            m=s.get(Market,sig.ticker)
            rules=s.execute(select(AlertRule).where(AlertRule.enabled==True,AlertRule.min_score<=sig.score,AlertRule.min_risk<=sig.risk_dollars)).scalars().all()
            for rule in rules:
                if rule.sport and m and rule.sport!=m.sport:continue
                tokens=s.execute(select(Device.push_token).where(Device.user_id==rule.user_id,Device.enabled==True)).scalars().all()
                if not tokens:continue
                title=f"{sig.label} {sig.score}/100 · ${sig.risk_dollars:,.0f}"
                body=f"{(m.title if m else sig.ticker)} · {sig.side.upper()} · public whale activity"
                await send_onesignal(list(tokens),title,body,{"ticker":sig.ticker,"side":sig.side,"signal_id":sig.id});sent+=1
            last=max(last,sig.id)
        obj=st or CollectorState(key="last_notified_signal_id");obj.value=str(last);s.merge(obj);s.commit();return sent
