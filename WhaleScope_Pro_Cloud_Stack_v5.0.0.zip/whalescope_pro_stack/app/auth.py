from __future__ import annotations
from fastapi import Header, HTTPException
from sqlalchemy import select
from .db import SessionLocal
from .models import User
from .config import settings

def current_user(authorization:str|None=Header(default=None), x_api_key:str|None=Header(default=None)):
    token=""
    if authorization and authorization.lower().startswith("bearer "): token=authorization.split(" ",1)[1].strip()
    token=token or (x_api_key or "")
    if settings.master_api_key and token==settings.master_api_key: return {"master":True,"id":0,"subscription_status":"active"}
    if not token: raise HTTPException(401,"missing access token")
    with SessionLocal() as s:
        u=s.execute(select(User).where(User.access_token==token)).scalar_one_or_none()
        if not u: raise HTTPException(401,"invalid access token")
        if u.subscription_status not in {"active","trial"}: raise HTTPException(402,"subscription inactive")
        return {"master":False,"id":u.id,"email":u.email,"subscription_status":u.subscription_status}
