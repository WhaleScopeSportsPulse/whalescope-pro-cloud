from __future__ import annotations
import json,time
from fastapi import FastAPI,Depends,Query,HTTPException,Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse,HTMLResponse
from pydantic import BaseModel,EmailStr
from sqlalchemy import select,func
from .config import settings
from .db import init_db,SessionLocal
from .models import Market,Trade,Signal,SignalFollowup,CollectorState,AlertRule,Device,User
from .auth import current_user
from .performance import stats
from .billing import create_checkout,ensure_user,activate_from_stripe_customer

app=FastAPI(title="WhaleScope Pro API",version="5.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=False,allow_methods=["GET","POST"],allow_headers=["*"])
@app.on_event("startup")
def startup(): init_db()

def state_value(key,default=""):
    with SessionLocal() as s:
        x=s.get(CollectorState,key);return x.value if x else default

@app.get("/health")
def health():
    with SessionLocal() as s:
        t=s.scalar(select(func.count()).select_from(Trade)) or 0
        sig=s.scalar(select(func.count()).select_from(Signal)) or 0
        resolved=s.scalar(select(func.count()).select_from(SignalFollowup).where(SignalFollowup.resolved==True)) or 0
    return {"ok":True,"version":"5.0.0","model_version":settings.model_version,"last_success_ts":int(state_value("last_success_ts","0") or 0),"last_error":state_value("last_error",""),"trades":t,"signals":sig,"resolved_followups":resolved}

@app.get("/api/status")
def status(user=Depends(current_user)):
    with SessionLocal() as s:
        trades=s.scalar(select(func.count()).select_from(Trade)) or 0
        markets=s.scalar(select(func.count()).select_from(Market).where(Market.sport!="")) or 0
        max_ts=s.scalar(select(func.max(Trade.ts))) or 0; min_ts=s.scalar(select(func.min(Trade.ts))) or 0
    return {"mode":"cloud","version":"5.0.0","last_success_ts":int(state_value("last_success_ts","0") or 0),"last_error":state_value("last_error",""),"new_trades_last_scan":int(state_value("last_inserted","0") or 0),"stats":{"trades":trades,"sports_markets":markets,"coverage_seconds":max(0,max_ts-min_ts)}}

@app.get("/api/whales")
def whales(hours:int=24,min_risk:float=1000,sports_only:int=1,block_only:int=0,limit:int=100,user=Depends(current_user)):
    cut=int(time.time())-max(1,min(hours,168))*3600
    with SessionLocal() as s:
        q=select(Signal,Trade,Market).join(Trade,Trade.trade_id==Signal.trade_id).join(Market,Market.ticker==Signal.ticker).where(Signal.ts>=cut,Signal.risk_dollars>=min_risk)
        if sports_only:q=q.where(Market.sport!="")
        if block_only:q=q.where(Trade.is_block_trade==True)
        rows=s.execute(q.order_by(Signal.ts.desc()).limit(min(500,limit))).all()
        out=[]
        for sig,t,m in rows:
            follow={f.horizon_seconds:f for f in sig.followups}
            f5=follow.get(300)
            out.append({"cluster_id":str(t.trade_id),"trade_id":t.trade_id,"ticker":sig.ticker,"event_ticker":m.event_ticker,"series_ticker":m.series_ticker,"title":m.title,"event_title":m.event_title,"series_title":m.series_title,"side":sig.side,"side_label":sig.side.upper(),"sport":m.sport,"category":m.category,"start_ts":sig.ts,"end_ts":sig.ts,"trade_count":sig.nearby_same_side,"contracts":t.count,"risk_dollars":sig.risk_dollars,"burst_risk_dollars":sig.burst_risk_dollars,"avg_entry":sig.entry_price,"is_block_trade":t.is_block_trade,"yes_price_start":t.yes_price,"yes_price_end":t.yes_price,"directional_move_cents":sig.directional_move_cents,"volume_24h_contracts":m.volume_24h,"open_interest_contracts":m.open_interest,"share_of_24h_volume_pct":sig.share_of_24h_volume_pct,"seconds_to_close":sig.seconds_to_close,"yes_bid":m.yes_bid,"yes_ask":m.yes_ask,"spread_cents":round(max(0,(m.yes_ask-m.yes_bid)*100),1) if m.yes_bid and m.yes_ask else None,"signal_score":sig.score,"signal_label":sig.label,"size_score":sig.size_score,"timing_score":sig.timing_score,"cluster_score":sig.cluster_score,"momentum_score":sig.momentum_score,"share_score":sig.share_score,"impact_5m_status":"WITH FLOW" if f5 and f5.resolved and (f5.directional_move_cents or 0)>=0 else "AGAINST FLOW" if f5 and f5.resolved else "PENDING","impact_5m_cents":f5.directional_move_cents if f5 and f5.resolved else None,"signal_reasons":json.loads(sig.reasons_json or "[]"),"model_version":sig.model_version})
    return {"clusters":out}

@app.get("/api/chart")
def chart(ticker:str,hours:int=24,user=Depends(current_user)):
    cut=int(time.time())-max(1,min(hours,168))*3600
    with SessionLocal() as s:
        rows=s.execute(select(Trade).where(Trade.ticker==ticker,Trade.ts>=cut).order_by(Trade.ts)).scalars().all()
    step=max(1,len(rows)//500) if rows else 1
    return {"ticker":ticker,"points":[{"ts":t.ts,"price":t.yes_price,"count":t.count} for i,t in enumerate(rows) if i%step==0]}

@app.get("/api/market")
def market(ticker:str,user=Depends(current_user)):
    with SessionLocal() as s:
        m=s.get(Market,ticker)
        if not m: raise HTTPException(404,"market not collected yet")
        rows=s.execute(select(Trade).where(Trade.ticker==ticker).order_by(Trade.ts.desc()).limit(200)).scalars().all()
    return {"market":{"ticker":m.ticker,"title":m.title,"sport":m.sport,"event_ticker":m.event_ticker,"series_ticker":m.series_ticker,"volume_24h_fp":m.volume_24h,"open_interest_fp":m.open_interest,"yes_bid":m.yes_bid,"yes_ask":m.yes_ask},"trades":[{"trade_id":t.trade_id,"ticker":t.ticker,"count_fp":t.count,"yes_price":t.yes_price,"no_price":t.no_price,"side":t.side,"price":t.no_price if t.side=="no" else t.yes_price,"risk_dollars":t.risk_dollars,"ts":t.ts,"is_block_trade":t.is_block_trade} for t in rows],"evidence":[],"watched":False}

@app.get("/api/performance")
def performance(min_score:int=68,horizon:int=1800,model_version:str|None=None,user=Depends(current_user)):
    return {"min_score":min_score,"horizon_seconds":horizon,"model_version":model_version or settings.model_version,**stats(min_score,horizon,model_version)}

@app.get("/api/performance/by-score")
def performance_by_score(horizon:int=1800,user=Depends(current_user)):
    bands=[("WATCH",36,51),("ELEVATED",52,67),("STRONG",68,81),("EXTREME",82,100)]
    out=[{"name":n,"min":lo,"max":hi,**stats(lo,horizon,settings.model_version,hi)} for n,lo,hi in bands]
    strong=stats(68,horizon,settings.model_version);watch=stats(36,horizon,settings.model_version,51)
    lift=None if strong["hit_positive_pct"] is None or watch["hit_positive_pct"] is None else round(strong["hit_positive_pct"]-watch["hit_positive_pct"],1)
    return {"horizon_seconds":horizon,"model_version":settings.model_version,"strong_vs_watch_lift_pp":lift,"bands":out}

class CheckoutIn(BaseModel): email: str
@app.post("/billing/checkout")
def billing_checkout(body:CheckoutIn): return create_checkout(body.email)

class DeviceIn(BaseModel): push_token:str; provider:str="onesignal"
@app.post("/api/device")
def register_device(body:DeviceIn,user=Depends(current_user)):
    if user.get("master"): raise HTTPException(400,"master key cannot register a device")
    with SessionLocal() as s:
        d=s.execute(select(Device).where(Device.push_token==body.push_token)).scalar_one_or_none()
        if not d:d=Device(user_id=user["id"],provider=body.provider,push_token=body.push_token);s.add(d)
        else:d.user_id=user["id"];d.enabled=True
        s.commit()
    return {"ok":True}

class RuleIn(BaseModel): min_score:int=68; min_risk:float=10000; sport:str=""; enabled:bool=True
@app.post("/api/alert-rule")
def alert_rule(body:RuleIn,user=Depends(current_user)):
    if user.get("master"): raise HTTPException(400,"master key cannot own alert rules")
    with SessionLocal() as s:
        r=s.execute(select(AlertRule).where(AlertRule.user_id==user["id"])).scalar_one_or_none()
        if not r:r=AlertRule(user_id=user["id"]);s.add(r)
        r.min_score=max(1,min(100,body.min_score));r.min_risk=max(0,body.min_risk);r.sport=body.sport.strip().lower();r.enabled=body.enabled;s.commit()
    return {"ok":True}


class LicenseIn(BaseModel):
    email:str
@app.post("/admin/license")
def admin_license(body:LicenseIn, request:Request):
    key=request.headers.get("X-API-Key","")
    if not settings.master_api_key or key!=settings.master_api_key: raise HTTPException(401,"master key required")
    u=ensure_user(body.email)
    return {"email":u.email,"access_token":u.access_token,"subscription_status":u.subscription_status}

@app.get("/billing/status")
def billing_status(user=Depends(current_user)):
    return {"subscription_status":user.get("subscription_status","active"),"plan":"WhaleScope Pro","price_monthly_usd":199}

@app.post("/billing/webhook")
async def stripe_webhook(request:Request):
    if not settings.stripe_secret_key or not settings.stripe_webhook_secret: raise HTTPException(503,"Stripe not configured")
    import stripe
    stripe.api_key=settings.stripe_secret_key
    payload=await request.body();sig=request.headers.get("stripe-signature","")
    try:event=stripe.Webhook.construct_event(payload,sig,settings.stripe_webhook_secret)
    except Exception as e: raise HTTPException(400,str(e))
    typ=event.get("type","");obj=event.get("data",{}).get("object",{})
    if typ=="checkout.session.completed":
        email=((obj.get("customer_details") or {}).get("email") or obj.get("customer_email") or "").lower()
        if email:
            u=ensure_user(email)
            with SessionLocal() as s:
                db=s.get(User,u.id);db.stripe_customer_id=str(obj.get("customer") or "");db.subscription_status="active";s.commit()
    elif typ in {"customer.subscription.updated","customer.subscription.deleted"}:
        cust=str(obj.get("customer") or "");status=str(obj.get("status") or "")
        activate_from_stripe_customer(cust,"active" if status in {"active","trialing"} else "inactive")
    return {"received":True}


@app.get("/billing", response_class=HTMLResponse)
def billing_page():
    return """<!doctype html><html><meta name='viewport' content='width=device-width,initial-scale=1'><title>WhaleScope Pro</title><style>body{font-family:system-ui;background:#07100d;color:#eafff5;display:grid;place-items:center;min-height:100vh;margin:0}.c{width:min(520px,90vw);border:1px solid #214237;border-radius:24px;padding:28px;background:#0a1511}h1{margin:0 0 8px}b{color:#39e7a8}input,button{box-sizing:border-box;width:100%;padding:14px;border-radius:12px;margin-top:12px;border:1px solid #2a4b40;background:#0b1914;color:white}button{background:#39e7a8;color:#04100c;font-weight:800}.m{color:#8ca69c;font-size:14px}</style><div class='c'><h1>WhaleScope <b>Pro</b></h1><h2>$199 / month</h2><p class='m'>Real-time public sports-flow monitoring, 24/7 signal ledger, forward-performance proof, advanced filters and alerts. A signal is unusual-activity analysis, not a guarantee of profit.</p><input id='e' type='email' placeholder='Email address'><button onclick='go()'>Continue to secure checkout</button><p id='s' class='m'></p></div><script>async function go(){s.textContent='Opening checkout…';let r=await fetch('/billing/checkout',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email:e.value})});let j=await r.json();if(j.checkout_url)location.href=j.checkout_url;else s.textContent='Billing is not configured on this server yet.'}</script></html>"""

@app.get("/billing/success", response_class=HTMLResponse)
def billing_success(session_id:str=""):
    token="";email=""
    if settings.stripe_secret_key and session_id:
        try:
            import stripe
            stripe.api_key=settings.stripe_secret_key
            obj=stripe.checkout.Session.retrieve(session_id)
            email=((obj.get("customer_details") or {}).get("email") or obj.get("customer_email") or "").lower()
            if email:
                u=ensure_user(email)
                with SessionLocal() as s:
                    db=s.get(User,u.id);db.stripe_customer_id=str(obj.get("customer") or "");db.subscription_status="active";s.commit();token=db.access_token
        except Exception: pass
    safe_token=token.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    return f"""<!doctype html><html><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{{font-family:system-ui;background:#07100d;color:#eafff5;padding:28px}}code{{display:block;word-break:break-all;padding:16px;background:#0b1914;border:1px solid #214237;border-radius:12px}}b{{color:#39e7a8}}</style><h1>WhaleScope <b>Pro activated</b></h1><p>Copy this access token into WhaleScope → Filters → Pro Cloud.</p><code>{safe_token or 'Your account was created, but the server could not display a token. Contact the server owner.'}</code></html>"""

@app.get("/billing/cancel", response_class=HTMLResponse)
def billing_cancel(): return "<h2>Checkout canceled. No subscription change was made.</h2>"
