from __future__ import annotations
import asyncio, json, time
from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from .config import settings
from .db import SessionLocal
from .models import Market, Trade, Signal, SignalFollowup, CollectorState
from .kalshi import KalshiClient
from .signal_engine import score_trade
from .util import f, parse_ts, detect_sport, jdumps

FOLLOWUPS=(60,300,900,1800,3600)

def normalize_trade(raw:dict):
    tid=str(raw.get("trade_id") or ""); ticker=str(raw.get("ticker") or raw.get("market_ticker") or "")
    if not tid or not ticker: return None
    yp=f(raw.get("yes_price_dollars"), f(raw.get("yes_price"))/100)
    np=f(raw.get("no_price_dollars"), f(raw.get("no_price"))/100)
    side=str(raw.get("taker_outcome_side") or raw.get("taker_side") or "yes").lower()
    if side not in {"yes","no"}: side="yes"
    count=f(raw.get("count_fp"),f(raw.get("count")))
    ts=parse_ts(raw.get("created_time")) or int(f(raw.get("ts"),time.time()))
    risk=count*(np if side=="no" else yp)
    return dict(trade_id=tid,ticker=ticker,ts=ts,side=side,yes_price=yp,no_price=np,count=count,risk_dollars=risk,is_block_trade=bool(raw.get("is_block_trade")),raw_json=jdumps(raw))

class Collector:
    def __init__(self): self.k=KalshiClient(); self.running=True
    async def close(self): await self.k.close()
    async def enrich_market(self,ticker:str,session):
        m=session.get(Market,ticker)
        now=datetime.now(timezone.utc)
        if m and m.updated_at:
            updated = m.updated_at if m.updated_at.tzinfo else m.updated_at.replace(tzinfo=timezone.utc)
            if (now-updated).total_seconds()<900: return m
        try:
            d=await self.k.market(ticker); raw=d.get("market",d)
        except Exception:
            if m: return m
            m=Market(ticker=ticker); session.add(m); session.flush(); return m
        event={}; series={}
        et=str(raw.get("event_ticker") or "")
        if et:
            try: event=(await self.k.event(et)).get("event",{})
            except Exception: event={}
        st=str(event.get("series_ticker") or raw.get("series_ticker") or "")
        if st:
            try: series=(await self.k.series(st)).get("series",{})
            except Exception: series={}
        if not m: m=Market(ticker=ticker); session.add(m)
        m.event_ticker=et; m.series_ticker=st
        m.title=str(raw.get("title") or event.get("title") or raw.get("yes_sub_title") or ticker)
        m.event_title=str(event.get("title") or ""); m.series_title=str(series.get("title") or "")
        m.category=str(series.get("category") or event.get("category") or raw.get("category") or "")
        tags=series.get("tags") or []
        m.sport=detect_sport(m.category,m.title,m.event_title,m.series_title," ".join(tags) if isinstance(tags,list) else str(tags),ticker)
        m.status=str(raw.get("status") or "")
        m.close_ts=parse_ts(raw.get("close_time") or raw.get("latest_expiration_time"))
        m.volume_24h=f(raw.get("volume_24h_fp"),f(raw.get("volume_24h")))
        m.open_interest=f(raw.get("open_interest_fp"),f(raw.get("open_interest")))
        m.yes_bid=f(raw.get("yes_bid_dollars"),f(raw.get("yes_bid"))/100)
        m.yes_ask=f(raw.get("yes_ask_dollars"),f(raw.get("yes_ask"))/100)
        m.liquidity_dollars=f(raw.get("liquidity_dollars"),f(raw.get("liquidity")))
        m.updated_at=now
        session.flush(); return m
    async def process_trade(self, raw:dict, session):
        n=normalize_trade(raw)
        if not n or session.get(Trade,n["trade_id"]): return False
        m=await self.enrich_market(n["ticker"],session)
        t=Trade(**n); session.add(t); session.flush()
        if not (m.sport or m.category.lower()=="sports") or t.risk_dollars<settings.signal_min_risk: return True
        lo=t.ts-120; hi=t.ts+120
        nearby=session.execute(select(Trade).where(Trade.ticker==t.ticker,Trade.ts>=lo,Trade.ts<=hi)).scalars().all()
        prior=session.execute(select(Trade).where(Trade.ticker==t.ticker,Trade.ts<t.ts,Trade.ts>=lo).order_by(Trade.ts.desc()).limit(1)).scalar_one_or_none()
        r=score_trade(trade=t,market=m,nearby=nearby,prior=prior)
        if r.score<settings.signal_store_min_score: return True
        sig=Signal(trade_id=t.trade_id,ticker=t.ticker,ts=t.ts,side=t.side,entry_price=t.no_price if t.side=="no" else t.yes_price,risk_dollars=t.risk_dollars,score=r.score,label=r.label,model_version=settings.model_version,size_score=r.size_score,timing_score=r.timing_score,cluster_score=r.cluster_score,momentum_score=r.momentum_score,share_score=r.share_score,nearby_same_side=r.nearby_same_side,burst_risk_dollars=r.burst_risk_dollars,directional_move_cents=r.directional_move_cents,share_of_24h_volume_pct=r.share_of_24h_volume_pct,seconds_to_close=r.seconds_to_close,reasons_json=jdumps(r.reasons))
        session.add(sig); session.flush()
        for h in FOLLOWUPS: session.add(SignalFollowup(signal_id=sig.id,horizon_seconds=h,target_ts=sig.ts+h))
        return True
    async def scan_once(self, initial=False):
        now=int(time.time());
        with SessionLocal() as s:
            st=s.get(CollectorState,"last_trade_ts")
            last=int(st.value) if st and st.value.isdigit() else 0
        min_ts=now-settings.backfill_hours*3600 if initial or not last else max(0,last-3)
        cursor=""; pages=0; inserted=0; max_ts=last
        while pages<(240 if initial else 8):
            d=await self.k.trades(min_ts,cursor,1000); rows=d.get("trades") or []
            with SessionLocal() as s:
                for raw in rows:
                    try:
                        ok=await self.process_trade(raw,s); inserted+=1 if ok else 0
                        n=normalize_trade(raw); max_ts=max(max_ts,n["ts"] if n else 0)
                    except IntegrityError: s.rollback()
                obj=s.get(CollectorState,"last_trade_ts") or CollectorState(key="last_trade_ts")
                obj.value=str(max_ts); obj.updated_at=datetime.now(timezone.utc); s.merge(obj)
                health=s.get(CollectorState,"last_success_ts") or CollectorState(key="last_success_ts")
                health.value=str(now); health.updated_at=datetime.now(timezone.utc); s.merge(health)
                count=s.get(CollectorState,"last_inserted") or CollectorState(key="last_inserted")
                count.value=str(inserted); count.updated_at=datetime.now(timezone.utc); s.merge(count)
                s.commit()
            cursor=str(d.get("cursor") or ""); pages+=1
            if not cursor: break
        return inserted
    async def run(self):
        initial=True
        while self.running:
            try: await self.scan_once(initial=initial); initial=False
            except Exception as e:
                with SessionLocal() as s:
                    x=s.get(CollectorState,"last_error") or CollectorState(key="last_error"); x.value=repr(e); x.updated_at=datetime.now(timezone.utc); s.merge(x); s.commit()
            await asyncio.sleep(max(2,settings.collector_poll_seconds))
