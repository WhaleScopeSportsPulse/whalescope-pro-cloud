# WhaleScope Pro Cloud Stack

This package is the server side that the Android-only build was missing. It is designed to run continuously so WhaleScope can collect public Kalshi sports trade data, freeze signals at the moment they fire, evaluate what happened afterward, and expose a proof/performance API to the app.

## What is implemented

- 24/7 public Kalshi trade collector with cursor-driven pagination and deep backfill.
- Lazy market/event/series enrichment and sports classification.
- Versioned signal engine (`MODEL_VERSION`) so old signals are never silently rescored after model changes.
- Frozen signal ledger with 1m, 5m, 15m, 30m, and 1h follow-up checkpoints.
- Maximum favorable/adverse movement tracking from the stored tape.
- Performance endpoints by score threshold and model version.
- PostgreSQL deployment configuration plus SQLite dev mode.
- Access tokens, subscription state, alert-rule tables, device-token tables.
- Optional Stripe Checkout adapter and optional OneSignal adapter. These activate only after the account keys are supplied.
- Docker Compose and Render deployment template.

## Run locally

```bash
cp .env.example .env
# For a no-Postgres smoke test, set DATABASE_URL=sqlite:///./whalescope.db
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8080
# second terminal
python -m app.worker
```

## Production

Use `docker compose up -d` or deploy the API + worker + Postgres with `deploy/render.yaml`. Change all example secrets first.

## Required external account values before this is truly 24/7 commercial service

1. A public cloud host / domain for the API and worker.
2. A Stripe account/product price if charging subscriptions.
3. A OneSignal (or another push provider) app ID/key if native remote push is desired.

Those are account credentials, not missing app logic. The collector/proof engine can run without Stripe or push.

## API used by the Android app

- `GET /health`
- `GET /api/status`
- `GET /api/whales`
- `GET /api/chart`
- `GET /api/market`
- `GET /api/performance`
- `GET /api/performance/by-score`

Protected endpoints accept `Authorization: Bearer <access-token>` or `X-API-Key`.

## Statistical caution

Do not advertise a hit rate until the live forward ledger has a meaningful sample. Keep model versions separate and show sample size next to every performance statistic. A large public execution is unusual-activity evidence, not proof that the bettor is an insider.
